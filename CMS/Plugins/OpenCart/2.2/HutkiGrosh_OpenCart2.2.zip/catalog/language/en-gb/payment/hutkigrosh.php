<?php
// Text
$_['text_title']    = 'hutkigrosh';
$_['text_reason'] 	= 'Reason';
$_['text_testmode']	= 'Payment Gateway in \'Sandbox \'. Funds from your account will not be removed.';
$_['text_total']	= 'Shipping, handling, and taxes are';
?>