<?php

$_['heading_title'] = 'HutkiGrosh';

$_['text_payment'] = 'Оплата';
$_['text_success'] = 'Настройки модуля обновлены!';


$_['text_storeid'] = 'Уникальный идентификатор услуги ЕРИП:';
$_['text_store'] = 'Название магазина:';
$_['text_login'] = 'Логин интернет-магазина:';
$_['text_pswd'] = 'Пароль Интернет магазина:';
$_['text_test'] = 'Режим песочницы:';
$_['text_status'] = 'Статус:';
$_['text_enabled'] = 'Включено';
$_['text_disabled'] = 'Отключено';
$_['text_save'] = 'Сохранить';
$_['text_cancel'] = 'Отмена';
$_['sort_order'] = 'Порядок сортировки';

$_['text_order_status_pending'] = 'Идентикатор статуса ожидания оплаты';
$_['text_order_status_payed'] = 'Идентикатор статуса успешнй оплаты';
$_['text_order_status_error'] = 'Идентикатор статуса ошибки оплаты';