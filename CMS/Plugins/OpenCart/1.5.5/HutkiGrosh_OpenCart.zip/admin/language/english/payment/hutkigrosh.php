<?php

$_['heading_title'] = 'HutkiGrosh';

$_['text_payment'] = 'Payment';
$_['text_success'] = 'Module settings have been updated!';


$_['text_storeid'] = 'Unique identifier of the store:';
$_['text_store'] = 'Store Name:';
$_['text_login'] = 'Login e-shop:';
$_['text_pswd'] = 'Password Online Shop:';
$_['text_test'] = 'Sandbox mode:';
$_['text_status'] = 'Status:';
$_['text_enabled'] = 'Enabled';
$_['text_disabled'] = 'Disabled';
$_['text_save'] = 'Savae';
$_['text_cancel'] = 'Cancel';
$_['sort_order'] = 'Sort order:';

$_['text_order_status_pending'] = 'Pending payment status id';
$_['text_order_status_payed'] = 'Payed status id';
$_['text_order_status_error'] = 'Error payment status id';