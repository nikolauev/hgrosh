<?php
/**
 * Created by PhpStorm.
 * User: nikit
 * Date: 25.01.2018
 * Time: 14:54
 */

namespace Drupal\commerce_hutkigrosh\api;


class AlfaclickRq
{
    public $billId;
    public $phone;
}