<?php
/**
 * Created by PhpStorm.
 * User: nikit
 * Date: 25.01.2018
 * Time: 14:53
 */

namespace Drupal\commerce_hutkigrosh\api;


class BillInfoRs
{
    public $eripId;
    public $invId;
    public $fullName;
    public $mobilePhone;
    public $email;
    public $fullAddress;
    public $amount;
    public $currency;
    public $products;
}