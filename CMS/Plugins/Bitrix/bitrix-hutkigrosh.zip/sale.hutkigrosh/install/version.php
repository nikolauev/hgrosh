<?
$arModuleVersion = array(
	"VERSION" => "1.0.0",
	"VERSION_DATE" => "2015-10-07 18:00:00"
);
?>