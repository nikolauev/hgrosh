<?
$MESS["hutkigrosh.payment_MODULE_NAME"] = "HutkiGrosh для Битрикс";
$MESS["hutkigrosh.payment_MODULE_DESC"] = "Платежный модуль для приема платежей c помощью системы ЕРИП";
$MESS["hutkigrosh.payment_PARTNER_NAME"] = "HutkiGrosh";
$MESS["hutkigrosh.payment_PARTNER_URI"] = "http://HutkiGrosh.by";
?>