<?
Class CArtpayPayment 
{
}
?>
