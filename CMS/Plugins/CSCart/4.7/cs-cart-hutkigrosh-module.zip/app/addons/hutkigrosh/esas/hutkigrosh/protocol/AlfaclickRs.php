<?php
/**
 * Created by PhpStorm.
 * User: nikit
 * Date: 27.02.2018
 * Time: 13:33
 */

namespace esas\hutkigrosh\protocol;


class AlfaclickRs extends HutkigroshRs
{

}